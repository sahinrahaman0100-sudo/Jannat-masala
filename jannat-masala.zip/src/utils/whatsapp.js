import { WHATSAPP_NUMBER } from "../config";

// Builds a wa.me link from a plain-text message.
export function waLink(message) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

// Full cart checkout message, including customer details.
export function buildCartMessage(cartItems, customer) {
  const lines = cartItems.map((item) => {
    const lineTotal = item.price * item.qty;
    return `${item.name} - ${item.weight} × ${item.qty} = ₹${lineTotal}`;
  });

  const totalItems = cartItems.reduce((sum, item) => sum + item.qty, 0);
  const totalPrice = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);

  return [
    "Hello Jannat Masala 👋",
    "I would like to place an order:",
    "",
    ...lines,
    "",
    `Total Items: ${totalItems}`,
    `Estimated Total: ₹${totalPrice}`,
    "",
    `Customer Name: ${customer.name}`,
    `Phone: ${customer.phone}`,
    `Address: ${customer.address}`,
    "",
    "Please confirm my order.",
    "Thank you!",
    "Jannat Masala",
  ].join("\n");
}

// Quick single-product order message, straight from a product card.
export function buildQuickOrderMessage(product, qty = 1) {
  const lineTotal = product.price * qty;
  return [
    "Hello Jannat Masala 👋",
    "I would like to order:",
    "",
    `${product.name} (${product.bengaliName}) - ${product.weight} × ${qty} = ₹${lineTotal}`,
    "",
    "Please confirm availability and delivery details.",
    "Thank you!",
  ].join("\n");
}

// Generic "just say hello" message for the hero / contact CTAs.
export function buildGreetingMessage() {
  return "Hello Jannat Masala 👋\nআমি আপনাদের মশলা সম্পর্কে জানতে চাই।";
}

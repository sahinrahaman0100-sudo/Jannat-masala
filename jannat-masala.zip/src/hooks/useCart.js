import { useMemo, useState } from "react";
import { products } from "../config";

export function useCart() {
  // cart is stored as { [productId]: qty }
  const [cart, setCart] = useState({});

  function addToCart(productId, qty = 1) {
    setCart((prev) => ({
      ...prev,
      [productId]: (prev[productId] || 0) + qty,
    }));
  }

  function increment(productId) {
    addToCart(productId, 1);
  }

  function decrement(productId) {
    setCart((prev) => {
      const current = prev[productId] || 0;
      if (current <= 1) {
        const next = { ...prev };
        delete next[productId];
        return next;
      }
      return { ...prev, [productId]: current - 1 };
    });
  }

  function removeFromCart(productId) {
    setCart((prev) => {
      const next = { ...prev };
      delete next[productId];
      return next;
    });
  }

  function clearCart() {
    setCart({});
  }

  const cartItems = useMemo(() => {
    return Object.entries(cart)
      .map(([id, qty]) => {
        const product = products.find((p) => p.id === Number(id));
        if (!product) return null;
        return { ...product, qty };
      })
      .filter(Boolean);
  }, [cart]);

  const cartCount = useMemo(
    () => cartItems.reduce((sum, item) => sum + item.qty, 0),
    [cartItems]
  );

  const cartTotal = useMemo(
    () => cartItems.reduce((sum, item) => sum + item.qty * item.price, 0),
    [cartItems]
  );

  return {
    cartItems,
    cartCount,
    cartTotal,
    addToCart,
    increment,
    decrement,
    removeFromCart,
    clearCart,
  };
}

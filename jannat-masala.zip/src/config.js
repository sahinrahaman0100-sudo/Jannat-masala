// ─────────────────────────────────────────────────────────
// JANNAT MASALA — BRAND CONFIG
// This is the only file you should ever need to touch.
// ─────────────────────────────────────────────────────────

export const WHATSAPP_NUMBER = "919775994656";
export const INSTAGRAM_URL = "https://instagram.com/jannat.masala";
export const INSTAGRAM_HANDLE = "@jannat.masala";

// 👉 Replace "image" with your own image URL for each product.
// You can add more products by copying a block and giving it a new id.
export const products = [
  {
    id: 1,
    name: "Haldi Guro",
    bengaliName: "হলুদ গুঁড়ো",
    price: 99,
    weight: "100g",
    image: "https://i.ibb.co/gLdtVKkQ/file-00000000dcec8211aa12fe62cf5abacf.png",
  },
  {
    id: 2,
    name: "Lonka Guro",
    bengaliName: "লঙ্কা গুঁড়ো",
    price: 99,
    weight: "100g",
    image: "https://i.ibb.co/Fk32szWV/file-00000000b248821192bdfed1d03faca8.png",
  },
  {
    id: 3,
    name: "Jeera Guro",
    bengaliName: "জিরা গুঁড়ো",
    price: 99,
    weight: "100g",
    image: "https://i.ibb.co/Rpq3P4jt/file-0000000023088211b83f0ede7a870259.png",
  },
  {
    id: 4,
    name: "Dhaniya Guro",
    bengaliName: "ধনে গুঁড়ো",
    price: 99,
    weight: "100g",
    image: "https://i.ibb.co/MybsBtQS/file-000000008984821187fbe67e718230ef.png",
  },
  {
    id: 5,
    name: "Garam Masala",
    bengaliName: "গরম মশলা",
    price: 129,
    weight: "50g",
    image: "CHANGE_PRODUCT_IMAGE_URL_HERE",
  },
];

// 👉 Replace the image URL for each recipe card.
export const recipes = [
  {
    id: "chicken-curry",
    name: "Chicken Curry",
    bengaliName: "চিকেন কারি",
    image: "CHANGE_CHICKEN_IMAGE_URL_HERE",
  },
  {
    id: "dal",
    name: "Dal",
    bengaliName: "ডাল",
    image: "CHANGE_DAL_IMAGE_URL_HERE",
  },
  {
    id: "aloo-dum",
    name: "Aloo Dum",
    bengaliName: "আলু দম",
    image: "CHANGE_ALOO_DUM_IMAGE_URL_HERE",
  },
];

// 👉 Replace with your own hero photo.
export const HERO_IMAGE_URL = "CHANGE_HERO_IMAGE_URL_HERE";

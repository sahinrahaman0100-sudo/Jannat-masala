import { useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import USPSection from "./components/USPSection";
import ProductsSection from "./components/ProductsSection";
import CartDrawer from "./components/CartDrawer";
import OrderFormModal from "./components/OrderFormModal";
import AboutSection from "./components/AboutSection";
import WhyChooseSection from "./components/WhyChooseSection";
import RecipesSection from "./components/RecipesSection";
import InstagramSection from "./components/InstagramSection";
import ContactSection from "./components/ContactSection";
import Footer from "./components/Footer";
import MobileBar from "./components/MobileBar";
import { useCart } from "./hooks/useCart";
import { waLink, buildCartMessage } from "./utils/whatsapp";

export default function App() {
  const {
    cartItems,
    cartCount,
    cartTotal,
    addToCart,
    increment,
    decrement,
    removeFromCart,
    clearCart,
  } = useCart();

  const [cartOpen, setCartOpen] = useState(false);
  const [formOpen, setFormOpen] = useState(false);

  function handleCheckout() {
    setCartOpen(false);
    setFormOpen(true);
  }

  function handleOrderSubmit(customer) {
    const message = buildCartMessage(cartItems, customer);
    window.open(waLink(message), "_blank", "noopener,noreferrer");
    setFormOpen(false);
    clearCart();
  }

  return (
    <div className="font-body pb-16 md:pb-0">
      <Navbar cartCount={cartCount} onOpenCart={() => setCartOpen(true)} />

      <main>
        <Hero />
        <USPSection />
        <ProductsSection onAddToCart={addToCart} />
        <AboutSection />
        <WhyChooseSection />
        <RecipesSection />
        <InstagramSection />
        <ContactSection />
      </main>

      <Footer />

      <MobileBar
        cartCount={cartCount}
        onOpenCart={() => setCartOpen(true)}
        onCheckout={handleCheckout}
      />

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        cartTotal={cartTotal}
        onIncrement={increment}
        onDecrement={decrement}
        onRemove={removeFromCart}
        onClearCart={clearCart}
        onCheckout={handleCheckout}
      />

      <OrderFormModal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        onSubmit={handleOrderSubmit}
      />
    </div>
  );
}

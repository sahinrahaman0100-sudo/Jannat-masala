import { Flame, Leaf, Soup, Users } from "lucide-react";

const items = [
  {
    icon: Flame,
    title: "Rich Aroma",
    desc: "রান্নার শুরুতেই ম ম করে ওঠে ঘরের গন্ধ।",
  },
  {
    icon: Leaf,
    title: "Carefully Selected Spices",
    desc: "যত্ন নিয়ে বাছাই করা মশলার উপকরণ।",
  },
  {
    icon: Soup,
    title: "Perfect for Everyday Cooking",
    desc: "রোজকার তরকারি থেকে বিশেষ পদ — সবেতেই মানানসই।",
  },
  {
    icon: Users,
    title: "Made for Bengali Kitchens",
    desc: "বাঙালি হেঁশেলের স্বাদ আর অভ্যাসকে মাথায় রেখে তৈরি।",
  },
];

export default function WhyChooseSection() {
  return (
    <section className="bg-spice-cream">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-16 md:py-20">
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-5">
          {items.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="bg-spice-offwhite rounded-2xl p-6 border border-spice-brown/10"
            >
              <div className="w-11 h-11 rounded-full bg-spice-red/10 flex items-center justify-center mb-4">
                <Icon className="w-5 h-5 text-spice-red" strokeWidth={1.75} />
              </div>
              <h3 className="font-body font-semibold text-[15.5px] text-spice-brown">
                {title}
              </h3>
              <p className="mt-1.5 font-body text-[13.5px] text-spice-brown/65 leading-relaxed">
                {desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

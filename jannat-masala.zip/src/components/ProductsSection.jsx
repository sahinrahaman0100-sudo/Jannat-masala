import { products } from "../config";
import ProductCard from "./ProductCard";

export default function ProductsSection({ onAddToCart }) {
  return (
    <section id="products" className="bg-spice-offwhite">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-16 md:py-20">
        <div className="max-w-lg">
          <h2 className="font-display text-[1.9rem] sm:text-3xl text-spice-brown">
            আমাদের মশলা
          </h2>
          <p className="mt-2 font-body text-[15px] text-spice-brown/65">
            আপনার রান্নার জন্য বেছে নিন পছন্দের Jannat Masala।
          </p>
        </div>

        <div className="mt-9 grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
          ))}
        </div>
      </div>
    </section>
  );
}

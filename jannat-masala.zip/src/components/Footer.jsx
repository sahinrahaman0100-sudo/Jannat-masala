import { INSTAGRAM_URL } from "../config";
import { waLink, buildGreetingMessage } from "../utils/whatsapp";

const links = [
  { label: "Home", href: "#home" },
  { label: "Products", href: "#products" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
  { label: "Instagram", href: INSTAGRAM_URL, external: true },
  { label: "WhatsApp", href: waLink(buildGreetingMessage()), external: true },
];

export default function Footer() {
  return (
    <footer className="bg-spice-brown text-spice-cream/80">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-12">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6">
          <div>
            <p className="font-display text-xl text-spice-offwhite">Jannat Masala</p>
            <p className="mt-1.5 font-body text-[14px] text-spice-cream/60">
              ঘরের রান্নায় আসল স্বাদের ছোঁয়া
            </p>
          </div>

          <nav className="flex flex-wrap gap-x-5 gap-y-2 font-body text-[13.5px]">
            {links.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target={link.external ? "_blank" : undefined}
                rel={link.external ? "noopener noreferrer" : undefined}
                className="hover:text-spice-turmeric transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>

        <p className="mt-8 pt-6 border-t border-spice-cream/10 font-body text-[12.5px] text-spice-cream/45">
          © 2026 Jannat Masala. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}

import { MessageCircle, MapPin, Instagram, Smartphone } from "lucide-react";
import { INSTAGRAM_HANDLE } from "../config";
import { waLink, buildGreetingMessage } from "../utils/whatsapp";

export default function ContactSection() {
  return (
    <section id="contact" className="bg-spice-red">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-16 md:py-20">
        <div className="max-w-lg">
          <h2 className="font-display text-[1.9rem] sm:text-3xl text-spice-offwhite">
            যোগাযোগ করুন
          </h2>
          <p className="mt-2 font-body font-semibold text-lg text-spice-offwhite">
            Jannat Masala
          </p>

          <ul className="mt-6 flex flex-col gap-3 font-body text-[15px] text-spice-cream/90">
            <li className="flex items-center gap-3">
              <Smartphone className="w-4 h-4 shrink-0" strokeWidth={1.75} />
              WhatsApp: +91 9775994656
            </li>
            <li className="flex items-center gap-3">
              <MapPin className="w-4 h-4 shrink-0" strokeWidth={1.75} />
              West Bengal, India
            </li>
            <li className="flex items-center gap-3">
              <Instagram className="w-4 h-4 shrink-0" strokeWidth={1.75} />
              {INSTAGRAM_HANDLE}
            </li>
          </ul>

          <a
            href={waLink(buildGreetingMessage())}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center gap-2 bg-spice-turmeric text-spice-brown font-body font-semibold text-[15px] px-7 py-3.5 rounded-full hover:bg-spice-turmericLight transition-colors"
          >
            <MessageCircle className="w-4 h-4" strokeWidth={2} />
            WhatsApp-এ যোগাযোগ করুন
          </a>
        </div>
      </div>
    </section>
  );
}

import { useState } from "react";
import { Minus, Plus, MessageCircle, ShoppingBag, Check } from "lucide-react";
import { waLink, buildQuickOrderMessage } from "../utils/whatsapp";

export default function ProductCard({ product, onAddToCart }) {
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  function handleAdd() {
    onAddToCart(product.id, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1400);
  }

  return (
    <div className="group bg-white rounded-2xl border border-spice-brown/10 overflow-hidden hover:shadow-lg hover:shadow-spice-brown/10 transition-shadow">
      <div className="aspect-square bg-spice-cream overflow-hidden">
        <img
          src={product.image}
          alt={`${product.name} — ${product.bengaliName}`}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </div>

      <div className="p-4 sm:p-5">
        <h3 className="font-body font-semibold text-[16px] text-spice-brown">
          {product.name}
        </h3>
        <p className="font-body text-[14px] text-spice-brown/60">{product.bengaliName}</p>

        <div className="mt-2 flex items-baseline gap-2">
          <span className="font-body font-bold text-[18px] text-spice-red">
            ₹{product.price}
          </span>
          <span className="font-body text-[13px] text-spice-brown/50">
            / {product.weight}
          </span>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center border border-spice-brown/15 rounded-full">
            <button
              aria-label="কমান"
              onClick={() => setQty((q) => Math.max(1, q - 1))}
              className="p-2 text-spice-brown hover:text-spice-red transition-colors"
            >
              <Minus className="w-3.5 h-3.5" strokeWidth={2} />
            </button>
            <span className="w-6 text-center font-body text-[14px] text-spice-brown">
              {qty}
            </span>
            <button
              aria-label="বাড়ান"
              onClick={() => setQty((q) => q + 1)}
              className="p-2 text-spice-brown hover:text-spice-red transition-colors"
            >
              <Plus className="w-3.5 h-3.5" strokeWidth={2} />
            </button>
          </div>

          <button
            onClick={handleAdd}
            className="flex items-center gap-1.5 bg-spice-brown text-spice-offwhite font-body text-[13px] font-semibold px-3.5 py-2.5 rounded-full hover:bg-spice-brownLight transition-colors"
          >
            {added ? (
              <Check className="w-4 h-4" strokeWidth={2} />
            ) : (
              <ShoppingBag className="w-4 h-4" strokeWidth={2} />
            )}
            {added ? "যোগ হয়েছে" : "কার্টে যোগ করুন"}
          </button>
        </div>

        <a
          href={waLink(buildQuickOrderMessage(product, qty))}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2.5 w-full flex items-center justify-center gap-2 border border-spice-red/30 text-spice-red font-body text-[13px] font-semibold py-2.5 rounded-full hover:bg-spice-red hover:text-white transition-colors"
        >
          <MessageCircle className="w-4 h-4" strokeWidth={2} />
          WhatsApp-এ অর্ডার করুন
        </a>
      </div>
    </div>
  );
}

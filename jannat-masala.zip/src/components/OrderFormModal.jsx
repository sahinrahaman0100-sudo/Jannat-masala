import { useState } from "react";
import { X } from "lucide-react";

export default function OrderFormModal({ open, onClose, onSubmit }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [touched, setTouched] = useState(false);

  if (!open) return null;

  const isValid = name.trim() && phone.trim() && address.trim();

  function handleSubmit(e) {
    e.preventDefault();
    setTouched(true);
    if (!isValid) return;
    onSubmit({ name: name.trim(), phone: phone.trim(), address: address.trim() });
    setName("");
    setPhone("");
    setAddress("");
    setTouched(false);
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-spice-brown/50 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full sm:max-w-md bg-spice-offwhite rounded-t-3xl sm:rounded-3xl p-6 sm:p-7 animate-popIn">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl text-spice-brown">আপনার তথ্য দিন</h2>
          <button
            aria-label="বন্ধ করুন"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-spice-cream transition-colors"
          >
            <X className="w-5 h-5 text-spice-brown" strokeWidth={1.75} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="block font-body text-[13.5px] text-spice-brown/70 mb-1.5">
              নাম
            </label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              type="text"
              placeholder="আপনার পুরো নাম"
              className="w-full rounded-xl border border-spice-brown/20 px-4 py-3 font-body text-[15px] text-spice-brown bg-white focus:border-spice-red outline-none"
            />
            {touched && !name.trim() && (
              <p className="mt-1 text-[12.5px] text-spice-red">নাম আবশ্যক</p>
            )}
          </div>

          <div>
            <label className="block font-body text-[13.5px] text-spice-brown/70 mb-1.5">
              ফোন নম্বর
            </label>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              type="tel"
              placeholder="98XXXXXXXX"
              className="w-full rounded-xl border border-spice-brown/20 px-4 py-3 font-body text-[15px] text-spice-brown bg-white focus:border-spice-red outline-none"
            />
            {touched && !phone.trim() && (
              <p className="mt-1 text-[12.5px] text-spice-red">ফোন নম্বর আবশ্যক</p>
            )}
          </div>

          <div>
            <label className="block font-body text-[13.5px] text-spice-brown/70 mb-1.5">
              ডেলিভারি ঠিকানা
            </label>
            <textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              rows={3}
              placeholder="বাড়ি নম্বর, রাস্তা, শহর, জেলা"
              className="w-full rounded-xl border border-spice-brown/20 px-4 py-3 font-body text-[15px] text-spice-brown bg-white focus:border-spice-red outline-none resize-none"
            />
            {touched && !address.trim() && (
              <p className="mt-1 text-[12.5px] text-spice-red">ঠিকানা আবশ্যক</p>
            )}
          </div>

          <button
            type="submit"
            className="mt-1 w-full bg-spice-red text-white font-body font-semibold text-[15px] py-3.5 rounded-full hover:bg-spice-redDark transition-colors"
          >
            WhatsApp-এ পাঠান
          </button>
        </form>
      </div>
    </div>
  );
}

import { ArrowDown, MessageCircle } from "lucide-react";
import { HERO_IMAGE_URL } from "../config";
import { waLink, buildGreetingMessage } from "../utils/whatsapp";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative overflow-hidden bg-spice-red"
      style={{
        backgroundImage:
          "radial-gradient(circle at 15% 20%, rgba(231,169,37,0.16) 0, transparent 45%), radial-gradient(circle at 85% 75%, rgba(231,169,37,0.12) 0, transparent 40%)",
      }}
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-8 pt-14 pb-20 md:pt-20 md:pb-28 grid md:grid-cols-2 gap-12 md:gap-8 items-center">
        <div className="animate-fadeUp">
          <div className="w-10 h-[3px] bg-spice-turmeric rounded-full mb-6" />

          <h1 className="font-display text-[2.15rem] leading-[1.25] sm:text-4xl sm:leading-[1.25] md:text-[2.75rem] md:leading-[1.28] text-spice-offwhite max-w-md">
            ঘরের রান্নায় আসল স্বাদের ছোঁয়া
          </h1>

          <p className="mt-5 font-body text-[16px] sm:text-lg text-spice-cream/90 max-w-sm">
            Jannat Masala — প্রতিদিনের রান্নায় খাঁটি মশলার স্বাদ।
          </p>

          <div className="mt-9 flex flex-col sm:flex-row gap-3">
            <a
              href="#products"
              className="inline-flex items-center justify-center gap-2 bg-spice-turmeric text-spice-brown font-body font-semibold text-[15px] px-7 py-3.5 rounded-full hover:bg-spice-turmericLight transition-colors"
            >
              মশলা দেখুন
              <ArrowDown className="w-4 h-4" strokeWidth={2} />
            </a>
            <a
              href={waLink(buildGreetingMessage())}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 border border-spice-offwhite/40 text-spice-offwhite font-body font-semibold text-[15px] px-7 py-3.5 rounded-full hover:bg-spice-offwhite/10 transition-colors"
            >
              <MessageCircle className="w-4 h-4" strokeWidth={2} />
              WhatsApp-এ অর্ডার করুন
            </a>
          </div>
        </div>

        <div className="relative animate-fadeUp" style={{ animationDelay: "0.1s" }}>
          <div
            className="absolute -inset-6 md:-inset-8 rounded-[3rem] bg-spice-turmeric/15"
            style={{ borderRadius: "62% 38% 55% 45% / 45% 55% 45% 55%" }}
          />
          <img
            src={HERO_IMAGE_URL}
            alt="Jannat Masala — ঘরে তৈরি খাঁটি মশলা"
            className="relative w-full aspect-[4/5] object-cover rounded-[2.5rem] shadow-2xl shadow-black/30"
          />
        </div>
      </div>
    </section>
  );
}

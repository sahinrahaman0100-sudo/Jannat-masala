import { recipes } from "../config";

export default function RecipesSection() {
  return (
    <section className="bg-spice-offwhite">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-16 md:py-20">
        <h2 className="font-display text-[1.9rem] sm:text-3xl text-spice-brown max-w-md">
          আজ কী রান্না হবে?
        </h2>

        <div className="mt-9 grid sm:grid-cols-3 gap-5 sm:gap-6">
          {recipes.map((recipe) => (
            <div
              key={recipe.id}
              className="relative rounded-2xl overflow-hidden aspect-[4/5] group"
            >
              <img
                src={recipe.image}
                alt={`${recipe.name} — ${recipe.bengaliName}`}
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-spice-brown/85 via-spice-brown/10 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <p className="font-display text-lg text-spice-offwhite">
                  {recipe.bengaliName}
                </p>
                <p className="mt-1 font-body text-[12.5px] text-spice-offwhite/85">
                  এই রান্নায় ব্যবহার করুন Jannat Masala
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

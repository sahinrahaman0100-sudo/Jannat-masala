import { useState } from "react";
import { Menu, X, ShoppingBag } from "lucide-react";

const links = [
  { label: "Home", href: "#home" },
  { label: "Products", href: "#products" },
  { label: "About Us", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar({ cartCount, onOpenCart }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-spice-offwhite/95 backdrop-blur border-b border-spice-brown/10">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
        <a href="#home" className="font-display text-2xl text-spice-red tracking-tight">
          Jannat Masala
        </a>

        <nav className="hidden md:flex items-center gap-8 font-body text-[15px] text-spice-brown">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="hover:text-spice-red transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            aria-label="কার্ট খুলুন"
            onClick={onOpenCart}
            className="relative p-2 rounded-full hover:bg-spice-cream transition-colors"
          >
            <ShoppingBag className="w-6 h-6 text-spice-brown" strokeWidth={1.75} />
            {cartCount > 0 && (
              <span
                key={cartCount}
                className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-spice-red text-spice-offwhite text-[11px] leading-[18px] text-center font-semibold animate-bump"
              >
                {cartCount}
              </span>
            )}
          </button>

          <button
            aria-label="মেনু খুলুন"
            onClick={() => setMenuOpen((v) => !v)}
            className="md:hidden p-2 rounded-full hover:bg-spice-cream transition-colors"
          >
            {menuOpen ? (
              <X className="w-6 h-6 text-spice-brown" strokeWidth={1.75} />
            ) : (
              <Menu className="w-6 h-6 text-spice-brown" strokeWidth={1.75} />
            )}
          </button>
        </div>
      </div>

      {menuOpen && (
        <nav className="md:hidden border-t border-spice-brown/10 bg-spice-offwhite px-5 py-3 flex flex-col gap-1">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="py-2.5 font-body text-[15px] text-spice-brown border-b border-spice-brown/5 last:border-0"
            >
              {link.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}

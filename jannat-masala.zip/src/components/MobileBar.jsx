import { ShoppingBag, MessageCircle } from "lucide-react";
import { waLink, buildGreetingMessage } from "../utils/whatsapp";

export default function MobileBar({ cartCount, onOpenCart, onCheckout }) {
  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t border-spice-brown/10 shadow-[0_-4px_16px_rgba(0,0,0,0.06)]">
      <div className="grid grid-cols-2 h-16">
        <button
          onClick={onOpenCart}
          className="flex items-center justify-center gap-2 font-body font-semibold text-[14px] text-spice-brown border-r border-spice-brown/10"
        >
          <span className="relative">
            <ShoppingBag className="w-5 h-5" strokeWidth={1.75} />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 min-w-[16px] h-[16px] px-1 rounded-full bg-spice-red text-white text-[10px] leading-[16px] text-center font-semibold">
                {cartCount}
              </span>
            )}
          </span>
          কার্ট
        </button>

        {cartCount > 0 ? (
          <button
            onClick={onCheckout}
            className="flex items-center justify-center gap-2 font-body font-semibold text-[14px] bg-spice-red text-white"
          >
            <MessageCircle className="w-5 h-5" strokeWidth={1.75} />
            WhatsApp Order
          </button>
        ) : (
          <a
            href={waLink(buildGreetingMessage())}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 font-body font-semibold text-[14px] bg-spice-red text-white"
          >
            <MessageCircle className="w-5 h-5" strokeWidth={1.75} />
            WhatsApp Order
          </a>
        )}
      </div>
    </div>
  );
}

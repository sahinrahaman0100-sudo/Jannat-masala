import { Leaf, Sparkles, Soup, Heart } from "lucide-react";

const items = [
  {
    icon: Leaf,
    title: "বাছাই করা মশলা",
    desc: "যত্ন সহকারে বাছাই করা প্রতিটি মশলা।",
  },
  {
    icon: Sparkles,
    title: "প্রিমিয়াম কোয়ালিটি",
    desc: "প্রতিটি প্যাকেটে মানের প্রতিশ্রুতি।",
  },
  {
    icon: Soup,
    title: "ঘরের রান্নার স্বাদ",
    desc: "মায়ের হাতের রান্নার মতোই আপন স্বাদ।",
  },
  {
    icon: Heart,
    title: "ভালোবাসা দিয়ে তৈরি",
    desc: "প্রতিটি ধাপে যত্ন আর ভালোবাসা।",
  },
];

export default function USPSection() {
  return (
    <section className="bg-spice-offwhite border-b border-spice-brown/10">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-12 md:py-14">
        <div className="grid sm:grid-cols-2 md:grid-cols-4 divide-y divide-spice-brown/10 sm:divide-y-0 md:divide-x">
          {items.map(({ icon: Icon, title, desc }, i) => (
            <div
              key={title}
              className={`flex items-start gap-3 py-5 sm:py-0 sm:px-5 first:pt-0 ${
                i % 2 === 1 ? "sm:pl-6" : ""
              } md:px-6 md:first:pl-0`}
            >
              <Icon className="w-5 h-5 text-spice-red mt-0.5 shrink-0" strokeWidth={1.75} />
              <div>
                <h3 className="font-body font-semibold text-[15px] text-spice-brown">
                  {title}
                </h3>
                <p className="mt-1 font-body text-[13.5px] text-spice-brown/70 leading-relaxed">
                  {desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { X, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";

export default function CartDrawer({
  open,
  onClose,
  cartItems,
  cartTotal,
  onIncrement,
  onDecrement,
  onRemove,
  onClearCart,
  onCheckout,
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div
        className="absolute inset-0 bg-spice-brown/40 backdrop-blur-sm"
        onClick={onClose}
      />

      <aside className="absolute right-0 top-0 h-full w-full max-w-sm bg-spice-offwhite shadow-2xl flex flex-col animate-drawerIn">
        <div className="flex items-center justify-between px-5 py-4 border-b border-spice-brown/10">
          <h2 className="font-display text-xl text-spice-brown">আপনার অর্ডার</h2>
          <button
            aria-label="কার্ট বন্ধ করুন"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-spice-cream transition-colors"
          >
            <X className="w-5 h-5 text-spice-brown" strokeWidth={1.75} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto thin-scroll px-5 py-4">
          {cartItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center gap-3 py-16">
              <ShoppingBag className="w-10 h-10 text-spice-brown/25" strokeWidth={1.5} />
              <p className="font-body text-[14px] text-spice-brown/60">
                আপনার কার্ট এখনো খালি।
              </p>
            </div>
          ) : (
            <ul className="flex flex-col gap-4">
              {cartItems.map((item) => (
                <li
                  key={item.id}
                  className="flex gap-3 pb-4 border-b border-spice-brown/10 last:border-0"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 rounded-xl object-cover bg-spice-cream shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-body font-semibold text-[14px] text-spice-brown truncate">
                          {item.name}
                        </p>
                        <p className="font-body text-[12.5px] text-spice-brown/55">
                          {item.weight} · ₹{item.price}
                        </p>
                      </div>
                      <button
                        aria-label="বাদ দিন"
                        onClick={() => onRemove(item.id)}
                        className="p-1 text-spice-brown/40 hover:text-spice-red transition-colors"
                      >
                        <Trash2 className="w-4 h-4" strokeWidth={1.75} />
                      </button>
                    </div>

                    <div className="mt-2 flex items-center justify-between">
                      <div className="flex items-center border border-spice-brown/15 rounded-full">
                        <button
                          aria-label="কমান"
                          onClick={() => onDecrement(item.id)}
                          className="p-1.5 text-spice-brown hover:text-spice-red transition-colors"
                        >
                          <Minus className="w-3 h-3" strokeWidth={2} />
                        </button>
                        <span className="w-5 text-center font-body text-[13px]">
                          {item.qty}
                        </span>
                        <button
                          aria-label="বাড়ান"
                          onClick={() => onIncrement(item.id)}
                          className="p-1.5 text-spice-brown hover:text-spice-red transition-colors"
                        >
                          <Plus className="w-3 h-3" strokeWidth={2} />
                        </button>
                      </div>
                      <span className="font-body font-semibold text-[14px] text-spice-brown">
                        ₹{item.price * item.qty}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {cartItems.length > 0 && (
          <div className="border-t border-spice-brown/10 px-5 py-4 bg-white">
            <div className="flex items-center justify-between mb-3">
              <button
                onClick={onClearCart}
                className="font-body text-[13px] text-spice-brown/50 hover:text-spice-red transition-colors"
              >
                কার্ট খালি করুন
              </button>
              <p className="font-body font-bold text-[17px] text-spice-brown">
                মোট: ₹{cartTotal}
              </p>
            </div>
            <button
              onClick={onCheckout}
              className="w-full bg-spice-red text-white font-body font-semibold text-[15px] py-3.5 rounded-full hover:bg-spice-redDark transition-colors"
            >
              WhatsApp-এ অর্ডার করুন
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}

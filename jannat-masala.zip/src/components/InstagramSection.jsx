import { Instagram } from "lucide-react";
import { INSTAGRAM_URL, INSTAGRAM_HANDLE } from "../config";

export default function InstagramSection() {
  return (
    <section className="bg-white border-y border-spice-brown/10">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-14 md:py-16 flex flex-col items-center text-center">
        <Instagram className="w-8 h-8 text-spice-red mb-4" strokeWidth={1.5} />
        <h2 className="font-display text-2xl sm:text-3xl text-spice-brown">
          Follow Jannat Masala
        </h2>
        <p className="mt-3 font-body text-[15px] text-spice-brown/70 max-w-md">
          আমাদের নতুন মশলা, রান্নার inspiration আর updates পেতে Instagram-এ আমাদের follow
          করুন।
        </p>
        <p className="mt-1 font-body text-[14px] text-spice-brown/50">{INSTAGRAM_HANDLE}</p>

        <a
          href={INSTAGRAM_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-6 inline-flex items-center gap-2 bg-spice-brown text-spice-offwhite font-body font-semibold text-[14.5px] px-7 py-3 rounded-full hover:bg-spice-brownLight transition-colors"
        >
          <Instagram className="w-4 h-4" strokeWidth={1.75} />
          Instagram-এ দেখুন
        </a>
      </div>
    </section>
  );
}

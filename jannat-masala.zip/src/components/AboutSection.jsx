export default function AboutSection() {
  return (
    <section id="about" className="bg-white border-y border-spice-brown/10">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-16 md:py-20">
        <div className="grid md:grid-cols-[1fr_1.4fr] gap-8 md:gap-14 items-start">
          <h2 className="font-display text-[1.9rem] sm:text-3xl text-spice-brown leading-tight">
            স্বাদের গল্প,
            <br />
            ভালোবাসার সাথে
          </h2>

          <div className="font-body text-[15.5px] sm:text-[16px] text-spice-brown/75 leading-[1.9] flex flex-col gap-4 max-w-xl">
            <p>
              Jannat Masala শুরু হয়েছিল একটা ছোট্ট ইচ্ছা থেকে — প্রতিদিনের বাঙালি রান্নাঘরে
              সহজে হাতের কাছে ভালো মশলা পৌঁছে দেওয়া। হলুদ, লঙ্কা, জিরা থেকে ধনে — প্রতিটা
              প্যাকেট তৈরি হয় রান্নার আসল স্বাদটা ধরে রাখার চেষ্টায়।
            </p>
            <p>
              West Bengal-এর ঘরে ঘরে যে স্বাদের সঙ্গে মানুষ বড় হয়েছে, সেই চেনা স্বাদটাই
              আমরা আপনার হেঁশেলে ফিরিয়ে আনতে চাই — সহজে, বিশ্বাসযোগ্যভাবে, আর একটু
              যত্নের সঙ্গে।
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

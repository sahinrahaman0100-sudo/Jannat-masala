/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        spice: {
          red: "#A32638",
          redDark: "#701C2A",
          redDeep: "#4E1420",
          turmeric: "#E7A925",
          turmericLight: "#F3C765",
          cream: "#FBF2E1",
          offwhite: "#FFFBF5",
          brown: "#3B2417",
          brownLight: "#5C3A28",
        },
      },
      fontFamily: {
        display: ['"Tiro Bangla"', "serif"],
        body: ['"Hind Siliguri"', "sans-serif"],
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        drawerIn: {
          "0%": { transform: "translateX(100%)" },
          "100%": { transform: "translateX(0)" },
        },
        popIn: {
          "0%": { transform: "scale(0.9)", opacity: "0" },
          "100%": { transform: "scale(1)", opacity: "1" },
        },
        bump: {
          "0%, 100%": { transform: "scale(1)" },
          "50%": { transform: "scale(1.18)" },
        },
      },
      animation: {
        fadeUp: "fadeUp 0.7s ease-out both",
        drawerIn: "drawerIn 0.35s cubic-bezier(0.32,0.72,0,1) both",
        popIn: "popIn 0.25s ease-out both",
        bump: "bump 0.3s ease-out",
      },
    },
  },
  plugins: [],
};
